cloud = {
	users_directory = "./users",
	nodes_head_directory = "./nodes_head",
	nodes_data_directory = "./nodes_data",
	access_log = "./access.log",
	invites_file = "./invites.txt"
}

launcher = {
	server_port = 1999
}
