{
	users_directory = "test_cloud/users",
	nodes_head_directory = "test_cloud/nodes_head",
	nodes_data_directory = "test_cloud/nodes_data",
	server_port = 1999,
	access_log = "test_cloud/access.log"
}
